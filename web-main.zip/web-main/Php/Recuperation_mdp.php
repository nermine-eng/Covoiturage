<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Inclusion des classes de PHPMailer
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Connexion à la base de données
$dbconn = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

// Vérifier si le formulaire a été soumis
if(isset($_POST['email'])) {

    // Récupérer l'e-mail saisi dans le formulaire
    $email = $_POST['email'];

    // Requête SQL pour récupérer le mot de passe correspondant à l'e-mail
    $query = "SELECT motdepasse FROM utilisateur WHERE email='$email'";

    // Exécution de la requête
    $result = pg_query($dbconn, $query);

    // Vérifier si l'e-mail existe dans la base de données
    if(pg_num_rows($result) > 0) {
        // Récupérer le mot de passe de l'utilisateur
        $row = pg_fetch_assoc($result);
        $motdepasse = $row['motdepasse'];

        // Envoyer le mot de passe à l'utilisateur par e-mail
        $mail = new PHPMailer(true);

        try {
            //Configurer le serveur SMTP
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'corideupssi@gmail.com'; // votre adresse email Gmail
            $mail->Password   = 'loughkceqkgxbikl';            // votre mot de passe Gmail
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            //Configurer l'email
            $mail->setFrom('votre_adresse_email@gmail.com', 'Coride Upssi');
            $mail->addAddress($email);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = 'Récupération de mot de passe';
            $mail->Body    = "Bonjour,\n\nVotre mot de passe est : " . $motdepasse . "\n\nCordialement,\nL'équipe de notre site web";

            //Envoyer l'email
            $mail->send();
            echo "Un e-mail contenant votre mot de passe a été envoyé à l'adresse $email.";
        } catch (Exception $e) {
            echo "Une erreur est survenue lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
        }
    } else {
        // L'e-mail n'existe pas dans la base de données
        echo "L'adresse e-mail $email n'existe pas dans notre base de données.";
    }
}
?>
