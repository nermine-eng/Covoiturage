<?php

include "Gabarit.php";

?>


<!DOCTYPE html>
  <title>Formulaire d annonce</title>
  <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">


<div class="tableau" style="align-items: flex-end">
  <!-- Formulaire d'ajout d'annonce de covoiturage -->
  <form method="POST" action="annoncee.php">
 
     <!-- Le titre de formulaire -->
    <h1 style="left: 20%">Proposez un trajet ! </h1>
   

    <!-- Champ pour la date de départ -->
    <label for="date-depart">Date de départ :</label>
    <input type="date" id="date-depart" name="date-depart" required><br>
    <!-- Champ pour la date d'arrivée -->
    <label for="date-arrivee">Date d'arrivée :</label>
    <input type="date" id="date-arrivee" name="date-arrivee" required><br>
    <!-- Champ pour l'heure de départ-->
    <label for="heure-depart">Départ :</label>
    <input type="time" id="heure-depart" name="heure-depart" placeholder="Heure de départ" required>
  
    <!-- Champ pour l'heure d'arrivée-->
    <label for="heure-arrivee">Arrivée :</label>
    <input type="time" id="heure-arrivee" name="heure-arrivee" placeholder="Heure d'arrivée" required>
    <!-- Champ pour le lieu de départ-->
    <label for="lieu-depart">Lieu de départ :</label>
    <input type="text" id="lieu-depart" name="lieu-depart" placeholder="Lieu de départ" required>
    <!-- Champ pour le lieu d'arrivee-->
    <label for="lieu-arrivee">Lieu d'arrivée :</label>
    <input type="text" id="lieu-arrivee" name="lieu-arrivee" placeholder="Lieu d'arrivée" required>
    <!-- Champ pour le numero d immatricule-->
    <label for="numero-immatricule">Numéro d'immatriculation :</label>
    <input type="text" id="numero-immatricule" name="numeroimmatricule" required><br>
    <!-- Champ pour insérer la marque de voiture-->
    <label for="marque">Marque :</label>
    <input type="text" id="marque" name="marque" required><br>
    <!-- Champ pour insérer le modèle de voiture-->
    <label for="modele">Modèle :</label>
    <input type="text" id="modele" name="modele" required><br>
    <!-- Champ pour insérer le nombre de sièges-->
    <label for="nombre-sieges">Nombre de sièges :</label>
    <input type="number" id="nombre-sieges" name="nombresieges" required><br>

    <!-- Champ pour insérer le nombre de passagers-->
    <label for="nombre-passagers">Nombre de passagers :</label>
    <input type="number" id="nombre-passagers" name="nombrepassagers" required><br>
    
    <!-- Champ pour insérer des informations supplémenta-->
    <label for="informations">Informations supplémentaires :</label>
    <textarea id="informations" name="informations"></textarea><br>
    
    <!--bouton pour publier l annonce-->

    <input type="submit" value="Publier">
  </form>
</div>
</html>

