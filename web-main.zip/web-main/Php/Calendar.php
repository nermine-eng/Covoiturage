<?php
// Include the "Gabarit.php" file, assuming it contains common functions or definitions
include 'Gabarit.php';

// Establish a connection to the database
$conn = OpenCon();

// Query to retrieve all users from the "utilisateur" table
$user_query = pg_query($conn, "SELECT * FROM utilisateur");

// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    $email = $_SESSION['email'];
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: Login.php");
}

// Query to retrieve the user's ID based on their email
$queryGetId = "SELECT * FROM utilisateur WHERE email = '$email' ";
$resultGetId = pg_query($conn, $queryGetId);

// Retrieve the user's ID from the query result
while ($row = pg_fetch_array($resultGetId)) {
    $idutilisateurResult = $row['idutilisateur'];
}

// Query the database to get the dates to mark in red from the "trajet" table
$query = "SELECT trajet.datedepart FROM trajet WHERE idtrajet = (SELECT idtrajet FROM proposer WHERE idutilisateur= $idutilisateurResult)";
$result = pg_query($conn, $query);

// Query the database to get additional dates to mark in red from the "trajet" table
$query1 = "SELECT trajet.datedepart from trajet where idtrajet = (select idtrajet from reserver where idutilisateur= $idutilisateurResult)";
$result1 = pg_query($conn, $query1);

// Collect the red-marked dates in an array
$red_dates = array();
while ($row = pg_fetch_row($result)) {
    $red_dates[] = $row[0];
    $dateValue = strtotime($row[0]);
}
while ($row = pg_fetch_row($result1)) {
    $red_dates[] = $row[0];
}

// Set the default date values if $dateValue is not set
if (isset($dateValue)) {
    $yr = date("Y", $dateValue) . " ";
    $mon = date("m", $dateValue) . " ";
    $date = date("d", $dateValue);
} else {
    $yr = date("Y") . " ";
    $mon = date("m") . " ";
    $date = date("d");
}

// Get the current month and year to display in the calendar
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Calculate the number of days in the current month
$num_days = cal_days_in_month(CAL_GREGORIAN, $mon, $yr);

// Calculate the day of the week that the first day of the month falls on
$first_day = mktime(0, 0, 0, $mon, 1, $yr);
$first_day_of_week = date('w', $first_day);

// Close the database connection
pg_close($conn);
?>
<!DOCTYPE html>
<html>
<title>Calendar</title>
<link rel="stylesheet" href="../Css/style.css">
<link rel="stylesheet" href="calendar.css">

<h1 style="margin-left:35%; margin-top: -5%; margin-bottom: -1%;"><b>Accédez au calendrier de vos</b></h1>
<h1 style="margin-left:50%;"><b>trajets !</b></h1>

<table style="margin-left:36%; font-size: xx-large; margin-top: 4%;">
    <tr>
        <th colspan="7"><?php echo date('F Y', $first_day); ?></th>
    </tr>
    <tr>
        <th>Sun</th>
        <th>Mon</th>
        <th>Tue</th>
        <th>Wed</th>
        <th>Thu</th>
        <th>Fri</th>
        <th>Sat</th>
    </tr>
    <tr>
        <?php
        // Print blank cells for days before the first day of the month
        for ($i = 0; $i < $first_day_of_week; $i++) {
            echo "<td>&nbsp;</td>";
        }

        // Print the days of the month
        for ($i = 1; $i <= $num_days; $i++) {
            $is_red = in_array(date('Y-m-d', mktime(0, 0, 0, $mon, $i, $yr)), $red_dates);
            echo "<td" . ($is_red ? " style=\"color:red\"" : "") . ">";
            if ($is_red) {
                // Create a link for red-marked dates
                echo "<a style=\"color: red;text-decoration-line: unset;\" href=\"../Php/historique.php\">" . $i . "</a>";
            } else {
                echo $i;
            }
            echo "</td>";

            if (($i + $first_day_of_week) % 7 == 0 && $i != $num_days) {
                echo "</tr><tr>";
            }
        }

        // Print blank cells for days after the last day of the month
        for ($i = 0; ($i + $first_day_of_week + $num_days) % 7 != 0; $i++) {
            echo "<td>&nbsp;</td>";
        }
        ?>
    </tr>
</table>
</body>
</html>
