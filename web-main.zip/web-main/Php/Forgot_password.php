<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Forgot Password</title>
        <link rel="stylesheet" href="../Css/style.css">
        <link rel="stylesheet" href="../Css/Forgot_password.css">
        <link rel="icon" type="image/png" href="tiret.png" class="tiret"> <!-- Définition du favicon en format PNG -->
        <script src="jquery-3.6.4.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
      </head>    
    <body>
        <header>
            <img src="../external_files/logo.png" alt="Logo de la page">
        
            <ul class="menu">
              <li>
                <a href="accueil.html" class="actif">Accueil</a>
              </li>
              <li>
                <a href="#">À propos</a>
              </li>
              <li>
                <a href="#">Aide</a>
              </li>
            </ul>
            <div>
              <img src="../external_files/image.png" alt="se connecter" class="b" id="mon-image">
              <ul>
                <li id="se-connecter"><a href="#">Se connecter</a></li>
                <li id="creer-compte"><a href="#">Créer un compte</a></li>
                <li id="se-deconnecter"><a href="#">Se déconnecter</a></li>
              </ul>
            </div>
        
            <script>
              const nav2 = document.querySelector('div');
              const nav2Links = nav2.querySelector('ul');
              const seConnecter = document.getElementById('se-connecter');
              const creerCompte = document.getElementById('creer-compte');
              const seDeconnecter = document.getElementById('se-deconnecter');
        
              // Ajouter un écouteur d'événement pour le clic sur l'image
              document.getElementById('mon-image').addEventListener('click', () => {
                // Afficher ou masquer les éléments de la liste
                nav2Links.classList.toggle('active');
                seConnecter.classList.toggle('hidden');
                creerCompte.classList.toggle('hidden');
                seDeconnecter.classList.toggle('hidden');
              });


              function toggleMenu() {
              var menuOptions = document.querySelector(".menus-options");
              var menu = document.querySelector(".menus");
              if (menuOptions.style.display === "block") {
                menuOptions.style.display = "none";
                menu.style.width = "200px";
              } else {
                menuOptions.style.display = "block";
                menu.style.width = "400px";
              }
            }
            console.log($('#email').val());
            // $("#forgot_password").click(function(){
            //     // $.ajax({
            //     //     type : 'POST',
            //     //     url : '../newPassword.php',
            //     //     data : { email: $('#email').val()},
            //     //     success: function(data)
            //     //     {
            //     //         $('#newPassword').html(data);
            //     //     }
            //     // });
            //     console.log("test");
            //     console.log($('#email').val());
            // });
            </script>
        
          </header>
        
        
          <!-- Bouton de menu -->
          <div class="menu-btn" onclick="toggleMenu()">
        
        
            <span class="text">Menu</span>
          </div>
        
          <!-- Menu horizontal -->
          <div class="menus">
            <!-- Options de menu -->
            <ul class="menus-options">
              <li class="menus-option"><a href="#">Proposer un trajet</a></li>
              <li class="menus-option"><a href="#">Accéder à l'historique</a></li>
              <li class="menus-option"><a href="#">Chat</a></li>
              <li class="menus-option"><a href="#">Calendrier</a></li>
              <li class="menus-option"><a href="#">Nous contacter</a></li>
            </ul>
          </div>
        
          <!-- Script pour afficher / masquer les options de menu -->

          <div class="blue-triangle"></div>
        
        
        <h1>Vous avez oublié votre mot de passe?</h1>

        <p>Afin de récupérer votre compte, veuillez renseignez </p>
        <p2>l'adresse mail utilisée lors de la création de votre compte.</p2>
    
    <form action="Recuperation_mdp.php" method="post" id="nameform">
          <label>EMAIL</label>
          <input type="email" id="email" name="email" placeholder="Veuillez saisir votre adresse mail"></br>
          <button type="submit" form="nameform" value="submit">Envoyer</button>
          <?php
         ?>
    </form>

</body>
</html>