<?php
include 'Gabarit.php';
session_start();
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$user_query=pg_query($db, "SELECT * FROM utilisateur");

$email = $_SESSION['email'];
$logged = $_SESSION['loggedin'];
$idtrajet = $_SESSION['buttonID'];
 $_SESSION['idtrajet_sup'] = $idtrajet;
$utilisateur = pg_query($db, "SELECT * FROM utilisateur");

?>

<!DOCTYPE html>


<div class="tableau" >
    <?php
    //function isAlreadyCanceled( $db, int $idUser, $idTrajet) {
        //$res = pg_query($db, "SELECT * FROM annuler WHERE idutilisateur = $idUser AND idtrajet = $idTrajet");
        //return pg_fetch_row($res) > 0;
    //}

    while ($row = pg_fetch_array($utilisateur)) {
        $emailcheck = $row['email'];
        $idutilisateur = $row['idutilisateur'];

        if($logged==true){
            if ($emailcheck==$email){
                $check = pg_query($db, "SELECT * FROM reserver WHERE reserver.idtrajet=$idtrajet AND reserver.idutilisateur=$idutilisateur");
                if ($row2 = pg_fetch_row($check)>0){
                    $query = pg_query($db, "DELETE FROM RESERVER WHERE idUtilisateur = $idutilisateur AND idTrajet = $idtrajet");
                    $query = pg_query($db, "UPDATE trajet SET nbplaces=nbplaces+1 WHERE idtrajet=$idtrajet ");
                    //if (isAlreadyCanceled($db, $idutilisateur, $idtrajet)) {
                        //$query = pg_query($db, "INSERT INTO annuler(idutilisateur, idtrajet) VALUES ($idtrajet, $idutilisateur)");
                    //}
                    echo "Votre trajet a été annulé !";
                }
                else{

                    echo "Vous ne participez pas à ce trajet ! ";
                }

            }
        }
        else{
            echo "You must be logged in !";
        }
    }?>
</div>

</body>

</html>