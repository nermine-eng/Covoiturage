<?php

session_start();

$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

$user_query=pg_query($db, "SELECT * FROM utilisateur");
$trajet_conducteur = pg_query($db, "SELECT * FROM trajet
INNER JOIN proposer ON trajet.idtrajet = proposer.idtrajet
INNER join utilisateur on proposer.idutilisateur = utilisateur.idutilisateur");

$participants = pg_query($db, "SELECT * FROM trajet
INNER JOIN reserver ON trajet.idtrajet = reserver.idtrajet
INNER join utilisateur on reserver.idutilisateur = utilisateur.idutilisateur");


$logged = $_SESSION['loggedin'];
$buttonID = $_GET['buttonID'];
$_SESSION['buttonID'] = $buttonID;
$_SESSION['buttonID_sup'] = $buttonID;

?>

<!DOCTYPE html>
    <link rel="stylesheet" href="../Css/Details.css">
<body>




<header>
    <img src="../external_files/logo.png" alt="Logo de la page">

    <ul class="menu">
        <li>
            <a href="Accueil.php" class="actif">Accueil</a>
        </li>
        <li>
            <a href="#">À propos</a>
        </li>
        <li>
            <a href="#">Aide</a>
        </li>
    </ul>
    <div>
        <?php

        $image = 'image.png';
        $check =0;
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            $email = $_SESSION['email'];
            while ($row = pg_fetch_array($user_query)) {
                $emailcheck = $row['email'];

                if ($email == $emailcheck) {
                    $usersurname = $row['nom'];
                    $username = $row['prenom'];
                    $image = $row['image'];
                    $admin_var = $row['admin_var'];
                    $check = 1;
                } else {
                    $image = 'image.png';
                    $check = 0;
                }
            }
        }
        echo "<img  src='../external_files/$image' alt='se connecter' class='b' id='mon-image'>" ?>

        <ul>
            <?php


            if($_SESSION['loggedin']==true){
                echo $username, $usersurname;
                echo '<li id="profil"><a href="../Php/Profil.php">Profil</a></li>';
                echo '<li id="se-deconnecter"><a href="Disconnect_function.php">Se déconnecter</a></li>';
            }

            else {
                // Si l'utilisateur n'est pas connecté, afficher le lien "Se connecter"
                echo '<li id="se-connecter"><a href="../Php/Login.php">Se connecter</a></li>';
                echo '<li id="creer-compte"><a href="../Php/Create_an_account%202.php">Créer un compte</a></li>';

            }
            ?>
        </ul>
    </div>

    <script>
        const nav2 = document.querySelector('div');
        const nav2Links = nav2.querySelector('ul');
        const seConnecter = document.getElementById('se-connecter');
        const creerCompte = document.getElementById('creer-compte');
        const seDeconnecter = document.getElementById('se-deconnecter');
        const profil = document.getElementById('profil');

        // Ajouter un écouteur d'événement pour le clic sur l'image
        document.getElementById('mon-image').addEventListener('click', () => {
            // Afficher ou masquer les éléments de la liste
            nav2Links.classList.toggle('active');
            if(seConnecter!=null){
                seConnecter.classList.toggle('hidden');
            }
            if (creerCompte!=null){
                creerCompte.classList.toggle('hidden');
            }
            if (seDeconnecter!=null){
                seDeconnecter.classList.toggle('hidden');
            }
            else{
                seDeconnecter.classList.toggle('visible');
            }
            if (profil!=null){
                profil.classList.toggle('hidden');
            }
        });

        function sendID_sup(buttonID_sup) {
            window.location.href = "Desinscrire.php?buttonID_sup=" + buttonID_sup;
        }
    </script>

</header>


<!-- Bouton de menu -->
<div class="menu-btn" onclick="toggleMenu()">


    <span class="text">Menu</span>
</div>

<!-- Menu horizontal -->
<div class="menus">
    <!-- Options de menu -->
    <ul class="menus-options">
        <li class="menus-option"><a href="#">Proposer un trajet</a></li>
        <li class="menus-option"><a href="../Php/historique.php">Accéder à l'historique</a></li>
        <li class="menus-option"><a href="#">Chat</a></li>
        <li class="menus-option"><a href="Calendar.php">Calendrier</a></li>
        <li class="menus-option"><a href="../Php/Contact.php">Nous contacter</a></li>
    </ul>
</div>

<!-- Script pour afficher / masquer les options de menu -->
<script>
    function toggleMenu() {
        var menuOptions = document.querySelector(".menus-options");
        var menu = document.querySelector(".menus");
        if (menuOptions.style.display === "block") {
            menuOptions.style.display = "none";
            menu.style.width = "200px";
        } else {
            menuOptions.style.display = "block";
            menu.style.width = "400px";
        }
    }
</script>
<div class="blue-triangle"></div>

<div class="tableau">
    <div class="right">
        <?= "
            <p class='participants_text'>Participants :</p>
            <ul class='participants'> ";

        if ($admin_var != 1) {
            while ($row = pg_fetch_array($participants)) {
                $idtrajet = $row['idtrajet'];
                $nomparticipant = $row['nom'];
                $prenomparticipant = $row['prenom'];

                if(isset($row['image'])){
                    $image = $row['image'];
                }
                else{
                    $image = 'image.png';
                }

                if ($idtrajet == $buttonID) {

                    echo "<li class='Participant'><img class='image' src='../external_files/$image'> ".$prenomparticipant." ".$nomparticipant."</li>";

                }

            }
            echo "</ul>";
        }
        else {
            while ($row = pg_fetch_array($participants)) {
                $idtrajet = $row['idtrajet'];
                $nomparticipant = $row['nom'];
                $prenomparticipant = $row['prenom'];
                $idutilisateur = $row['idutilisateur'];

                if(isset($row['image'])){
                    $image = $row['image'];
                }
                else{
                    $image = 'image.png';
                }

                if ($idtrajet == $buttonID) {

                    echo "<li class='Participant'><img class='image' src='../external_files/$image'> ".$prenomparticipant." ".$nomparticipant."</li>
                          <button class='reserver' id='$idutilisateur' onclick='sendID_sup(this.id)'>
                            <a > Désinscrire </a>
                          </button>";


                }

            }
            echo "</ul>";
        }



        while ($row = pg_fetch_array($trajet_conducteur)) {
        $lieudepart = $row['lieudepart'];
        $lieuarrivee = $row['lieuarrivee'];
        $heuredepart = $row['heuredepart'];
        $heurearrivee = $row['heurearrivee'];
        $datedepart = $row['datedepart'];
        $datearrivee = $row["datearrivee"];
        $idtrajet = $row['idtrajet'];
        $idconducteur = $row['idutilisateur'];
        $prenomconducteur = $row['prenom'];
        $nomconducteur = $row['nom'];
        $nbplacesdispo = $row['nbplaces'];

        if ($idtrajet == $buttonID) {

        echo "<ul class='conducteur'>";

        echo "<li> Conducteur : <img class='image' src='../external_files/$image'>".$prenomconducteur." ".$nomconducteur."</li>";
        echo "</ul>";
        ?>
    </div>
    <?= "<ul class='infos'>";
    echo "<li>Lieu/date/heure de départ : ".$lieudepart." / ".$datedepart." / ".$heuredepart."</li>";

    echo "<li>Lieu/date/heure d'arrivée : ".$lieuarrivee." / ".$datearrivee." / ".$heurearrivee."</li>";

    echo "<li>Nombre de places disponibles : $nbplacesdispo </li>";
    echo "</ul>";

    }
    }
    ?>

</div>
<div class="participer">
    <?php
    if ($admin_var!=1){
        echo "<button class='reserver' id='reserver'>
            <a href='Reserver_trajet.php'> Reserver </a>
        </button>
        <button class='annuler' id='anuler'>
            <a href='Annuler_trajet.php'> Annuler </a>
        </button>";
    }
    else{
        echo "<button class='reserver' id='reserver'>
            <a href='Supprimer_trajet.php'> Supprimer </a>
        </button>";
    }
    ?>
</div>


</body>

</html>