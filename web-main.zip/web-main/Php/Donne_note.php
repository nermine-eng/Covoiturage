<?php
var_dump($_POST);

// Connexion à la base de données
include('dbConnect.php');
$conn = OpenCon();

//Récupérer les valeurs du formulaire
$idUtilisateur = $_POST["idUtilisateur"];
$idTrajet = $_POST["idTrajet"];
$note = $_POST["note"];

$requete = "INSERT INTO DONNERAVIS (idUtilisateur, idTrajet, note) VALUES ($idUtilisateur, $idTrajet, $note)";
$resultat = pg_query($conn, $requete);

if ($resultat) {
  echo "Avis enregistré avec succès !";
} else {
  echo "Erreur lors de l'enregistrement de l'avis.";
}


// Fermeture de la connexion à la base de données
CloseCon($conn);

?>



