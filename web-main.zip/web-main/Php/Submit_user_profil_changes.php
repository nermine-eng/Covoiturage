<?php
// Connexion à la base de données PostgreSQL
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

session_start();
$email = $_SESSION['email']; // Récupération de l'adresse e-mail de l'utilisateur à partir de la session
$nom = $_POST['nom']; // Récupération du nom à partir du formulaire
$prenom = $_POST['prenom']; // Récupération du prénom à partir du formulaire
$age = $_POST['date_naissance']; // Récupération de la date de naissance à partir du formulaire
$motDePasse = $_POST['mot_de_passe']; // Récupération du mot de passe à partir du formulaire

$originalFileName = $_FILES['nouvphoto']['name']; // Récupération du nom original du fichier téléchargé à partir de l'élément 'nouvphoto' dans le formulaire
$targetDirectory = '../external_files/'; // Définition du répertoire cible où le fichier sera sauvegardé
$uploadOk = 1; // Variable pour vérifier si le téléchargement du fichier est autorisé
$imageFileType = strtolower(pathinfo($originalFileName, PATHINFO_EXTENSION)); // Récupération de l'extension du fichier (en minuscules) à partir du nom original du fichier

// Generate a unique filename based on the user
$targetFile = $targetDirectory . $email .'.jpg';
$photo = $email . '.jpg';
// ... (Rest of the validation checks)

// Move the uploaded file to the target directory
 if ($uploadOk == 1) {
    if ($_FILES['nouvphoto']['tmp_name']!=NULL){
      if (move_uploaded_file($_FILES['nouvphoto']['tmp_name'], $targetFile)) {
        // File has been successfully uploaded, and you can save the file path to the user's account in your database.
        echo "File uploaded successfully.";
        // Save the file path in your database or perform any other necessary actions.
      }
    }
    else {
        $photo = "image.png";
        //$ext = "";
        echo "Default file added";
      }

} else {
    // Récupérer la photo existante de la base de données si l'utilisateur n'a pas fourni de nouvelle photo
    $query = "SELECT image FROM UTILISATEUR WHERE email='$email'";
    $result = pg_query($db, $query);


}

$query = "UPDATE UTILISATEUR SET nom='$nom', prenom='$prenom', age='$age', motdepasse='$motDePasse' WHERE email='$email'";

$result = pg_query($db, $query); // Exécuter la requête de mise à jour des informations de l'utilisateur dans la base de données


if(isset($photo)){
    $query2 = "UPDATE Utilisateur SET image='$photo' WHERE email='$email'";
    $result2 = pg_query($db, $query2); // Exécuter la requête de mise à jour de l'image de profil de l'utilisateur dans la base de données
}


if ($result) {
    echo "<script>alert('Votre Profil a été mis à jour avec succès!')</script>";

} else {
    echo "Query failed."; // Afficher un message d'échec si la requête de mise à jour échoue
}
header("Location: ../Php/Profil.php"); // Redirige l'utilisateur vers la page de profil
pg_close($db);
?>
