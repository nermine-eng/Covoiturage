<!DOCTYPE html>
    <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">
</html>

<?php

// Connexion à la base de données
include('dbConnect.php');
$conn = OpenCon();



// Récupération des valeurs du formulaire
$lieuDepart = $_POST['lieu-depart'];
$lieuArrivee = $_POST['lieu-arrivee'];
$dateDepart = $_POST['date-depart'];
$datearrivee = $_POST['date-arrivee'];
$heureDepart = $_POST['heure-depart'];
$heureArrivee = $_POST['heure-arrivee'];
$nbPlaces = $_POST['nombrepassagers'];
$numeroImmatricule = $_POST["numeroimmatricule"];
$modele = $_POST["modele"];
$marque = $_POST["marque"];
$nombreSieges = $_POST["nombresieges"];
$informations = $_POST["informations"];

$queryVoiture = "INSERT INTO VOITURE (immatricule, modele, marque, nbplacesdispo, specification)
                VALUES ('$numeroImmatricule', '$modele', '$marque', '$nombreSieges', '$informations')";

// Exécution de la requête d'insertion dans la table VOITURE
$resultVoiture = pg_query($conn, $queryVoiture);

// Vérification de l'insertion des données dans la table VOITURE
if (!$resultVoiture) {
    echo "Erreur lors de l'insertion des données dans la table VOITURE.";
    exit;
}

// Requête d'insertion des données dans la table TRAJET
$sql = "INSERT INTO TRAJET (lieudepart, lieuarrivee, datedepart, datearrivee, heuredepart, heurearrivee, nbplaces) VALUES ('$lieuDepart', '$lieuArrivee', '$dateDepart', '$datearrivee', '$heureDepart', '$heureArrivee',' $nbPlaces')";
        

// Exécution de la requête d'insertion dans la table TRAJET
$resultTrajet = pg_query($conn, $sql);



// Affichage des données insérées dans la table VOITURE

// Requête de sélection des données insérées dans la table VOITURE
$querySelectVoiture = "SELECT * FROM VOITURE WHERE immatricule = '$numeroImmatricule'";

// Exécution de la requête de sélection
$resultSelectVoiture = pg_query($conn, $querySelectVoiture);

// Affichage des résultats sous forme de tableau
include "Gabarit.php";

echo "<div class='tableau'>";
echo "La trajet a bien été crée !";
//fermeture de la connexion à la base de données
CloseCon($conn);

?>
