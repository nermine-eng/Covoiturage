<?php


include 'dbConnect.php';
$conn = OpenCon();
$user_query=pg_query($conn, "SELECT * FROM utilisateur");

?>
<!DOCTYPE html>

<head>
    <title>Titre de la page</title>
    <link rel="stylesheet" href="../Css/Accueil.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset='UTF-8' >
    <link rel="icon" type="image/png" href="../external_files/tiret.png" class="tiret"> <!-- Définition du favicon en format PNG -->
</head>

<body>




<header>
    <img src="../external_files/logo.png" alt="Logo de la page">

    <ul class="menu">
        <li>
            <a href="Accueil.php" class="actif">Accueil</a>
        </li>
        <li>
            <a href="Accueil.php">À propos</a>
        </li>
        <li>
            <a href="Accueil.php">Aide</a>
        </li>
    </ul>
    <div>
        <?php
        session_start();
        $image = 'image.png';
        $check =0;
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            $email = $_SESSION['email'];
            while ($row = pg_fetch_array($user_query)) {
                $emailcheck = $row['email'];

                if ($email == $emailcheck) {
                    $usersurname = $row['nom'];
                    $username = $row['prenom'];
                    $image = $row['image'];
                    $check = 1;
                } else {
                    $image = 'image.png';
                    $check = 0;
                }
            }
        }
        echo "<img  src='../external_files/$image' alt='se connecter' class='b' id='mon-image'>" ?>

        <ul class="usermenu">
            <?php


            if(isset($_SESSION['loggedin']) AND $_SESSION['loggedin']==1){
                echo $username, $usersurname;
                echo '<li id="profil"><a href="../Php/Profil.php">Profil</a></li>';
                echo '<li id="se-deconnecter"><a href="Disconnect_function.php">Se déconnecter</a></li>';
            }

            else {
                // Si l'utilisateur n'est pas connecté, afficher le lien "Se connecter"
                echo '<li id="se-connecter"><a href="../Php/Login.php">Se connecter</a></li>';
                echo '<li id="creer-compte"><a href="../Php/CreateAnAccount.php">Créer un compte</a></li>';

            }
            ?>
        </ul>
    </div>

    <script>
        const nav2 = document.querySelector('div');
        const nav2Links = nav2.querySelector('ul');
        const seConnecter = document.getElementById('se-connecter');
        const creerCompte = document.getElementById('creer-compte');
        const seDeconnecter = document.getElementById('se-deconnecter');
        const profil = document.getElementById('profil');

        // Ajouter un écouteur d'événement pour le clic sur l'image
        document.getElementById('mon-image').addEventListener('click', () => {
            // Afficher ou masquer les éléments de la liste
            nav2Links.classList.toggle('active');
            if(seConnecter!=null){
                seConnecter.classList.toggle('hidden');
            }
            if (creerCompte!=null){
                creerCompte.classList.toggle('hidden');
            }
            if (seDeconnecter!=null){
                seDeconnecter.classList.toggle('hidden');
            }
            else{
                seDeconnecter.classList.toggle('visible');
            }
            if (profil!=null){
                profil.classList.toggle('hidden');
            }
        });
    </script>

</header>


<!-- Bouton de menu -->
<div class="menu-btn" onclick="toggleMenu()">


    <span class="text">Menu</span>
</div>

<!-- Menu horizontal -->
<div class="menus">
    <!-- Options de menu -->
    <ul class="menus-options">
        <li class="menus-option"><a href="../Php/annonce.php">Proposer un trajet</a></li>
        <li class="menus-option"><a href="../Php/historique.php">Accéder à l'historique</a></li>
        <li class="menus-option"><a href="#">Chat</a></li>
        <li class="menus-option"><a href="Calendar.php">Calendrier</a></li>
        <li class="menus-option"><a href="../Php/Contact.php">Nous contacter</a></li>
    </ul>
</div>

<!-- Script pour afficher / masquer les options de menu -->
<script>
    function toggleMenu() {
        var menuOptions = document.querySelector(".menus-options");
        var menu = document.querySelector(".menus");
        if (menuOptions.style.display === "block") {
            menuOptions.style.display = "none";
            menu.style.width = "200px";
        } else {
            menuOptions.style.display = "block";
            menu.style.width = "400px";
        }
    }
</script>
<div class="blue-triangle"></div>






</body>

</html>