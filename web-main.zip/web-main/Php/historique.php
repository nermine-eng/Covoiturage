<!DOCTYPE html>
<script>


    function sendID(buttonID) {
        window.location.href = "Details.php?buttonID=" + buttonID;
    }

</script>
  <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">
  <style>.styled-table {
    width: 80%;
    border-collapse: collapse;
    font-size: 14px;
    margin-left: 10%;
      margin-top: 10%;
}

.styled-table thead th {
    background-color: #f8f8f8;
    color: #333;
    font-weight: bold;
    padding: 10px;
    text-align: left;
}

.styled-table tbody td {
    border: 1px solid #ddd;
    padding: 8px;
}

.styled-table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

.styled-table tbody tr:hover {
    background-color: #ddd;
}

.styled-table tbody td:first-child {
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
}

.styled-table tbody td:last-child {
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
}
</style>

</html>
<?php


//$conn = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$session = session_start();
// Connexion à la base de données
if (!isset($session)){
    session_start();
}

$email = $_SESSION['email'];


include "Gabarit.php";




// Requête SELECT pour afficher les trajets réservés
$sql = "SELECT t.lieuDepart, t.dateDepart, t.lieuArrivee, t.idTrajet, CURRENT_DATE - t.dateDepart as dif_date, u.prenom, u.nom
FROM TRAJET t
JOIN RESERVER r ON r.idTrajet = t.idTrajet 
JOIN PROPOSER p on p.idTrajet = t.idTrajet
JOIN UTILISATEUR u ON u.idUtilisateur = p.idUtilisateur
WHERE u.email ='$email';
";




// Exécution de la requête
$result = pg_query($conn, $sql);

// Affichage des résultats sous forme de tableau
// Début de la section PHP
// ...

// Construction de la structure de la table

$i = 0;

while ($row = pg_fetch_row($result)) {
    $idtrajet = $row[3];
    $tableHtml = "<table class='styled-table' >";
    $tableHtml .= "
                <thead>
                    <tr>
                        <th>Lieu de départ</th>
                        <th>Lieu d'arrivée</th>
                        <th>Date de départ</th>
                        <th>Heure de départ</th>
                        <th>Nom du passager</th>
                        <th>Prénom du passager</th>
                        <th>
                            <a >
                            <button id=$idtrajet onclick='sendID(this.id)'>
                        Détails
                        </button>
                            </a>
                         
</th>
                    </tr>
                   
                </thead>";
    $tableHtml .= "<tbody>";

    $tableHtml .= "<tr>";
    $tableHtml .= "<td>" . $row[0] . "</td>";
    $tableHtml .= "<td>" . $row[2] . "</td>";
    $tableHtml .= "<td>" . $row[1] . "</td>";
    $tableHtml .= "<td>" . $row[4] . "</td>";

    $tableHtml .= "<td>" . $row[6] . "</td>";
    $tableHtml .= "<td>" . $row[5] . "</td>";

    $tableHtml .= "</tr>";
    $tableHtml .= "</tbody>";
    $tableHtml .= "</table>";

    echo $tableHtml;
}



// Fin de la section PHP

// Affichage du contenu HTML



    
    

    
 



// Fermeture de la connexion à la base de données

?>
