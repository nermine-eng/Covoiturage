
<?php

include 'Gabarit.php';

$db = OpenCon();
$user_query=pg_query($db, "SELECT * FROM utilisateur");

?>
<!DOCTYPE html>
    <title>Page Profil</title>
    <link rel="stylesheet" href="../Css/Profil.css">

    <?php
        // Inclure le fichier User_profile_edit_function.php
        include('User_profile_edit_function.php');
    ?>




</body>

</html>