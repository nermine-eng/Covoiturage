<!DOCTYPE html>

<head>
    <title>Page de contact</title>
    <link rel="stylesheet" href="../Css/Contact.css">
    <meta charset='UTF-8'>
    <link rel="icon" type="image/png" href="tiret.png" class="tiret"> <!-- Définition du favicon en format PNG -->
</head>

<body>




    <header>
    <img src="../external_files/logo.png" alt="Logo de la page">

    <ul class="menu">
        <li>
            <a href="Accueil.php" class="actif">Accueil</a>
        </li>
        <li>
            <a href="Accueil.php">À propos</a>
        </li>
        <li>
            <a href="Accueil.php">Aide</a>
        </li>
    </ul>
    <div>
        <?php
        // Connexion à la base de données PostgreSQL
        $db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
        // Requête pour récupérer tous les utilisateurs
        $user_query=pg_query($db, "SELECT * FROM utilisateur");
        
        // Démarrer la session
        session_start();
        $image = 'image.png';

        // Vérification de la connexion de l'utilisateur
        $check =0;
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

            // Récupération de l'email de l'utilisateur connecté depuis la session
            $email = $_SESSION['email'];

            // Parcours des résultats de la requête des utilisateurs
            while ($row = pg_fetch_array($user_query)) {
                $emailcheck = $row['email'];

            // Vérification si l'email correspond à l'utilisateur connecté
                if ($email == $emailcheck) {
                    $usersurname = $row['nom'];
                    $username = $row['prenom'];
                    $image = $row['image'];
                    $check = 1;
                } else {
            // Utilisation de l'image par défaut et réinitialisation du check
                    $image = 'image.png';
                    $check = 0;
                }
            }
        }
        echo "<img  src='../external_files/$image' alt='se connecter' class='b' id='mon-image'>" ?>

        <ul class="usermenu">
            <?php

            // Vérification de la connexion de l'utilisateur et affichage des liens de profil et de déconnexion

            if(isset($_SESSION['loggedin']) AND $_SESSION['loggedin']==1){
                echo $username, $usersurname;
                echo '<li id="profil"><a href="../Php/Profil.php">Profil</a></li>';
                echo '<li id="se-deconnecter"><a href="Disconnect_function.php">Se déconnecter</a></li>';
            }

            else {
                // Si l'utilisateur n'est pas connecté, afficher le lien "Se connecter"
                echo '<li id="se-connecter"><a href="../Php/Login.php">Se connecter</a></li>';
                echo '<li id="creer-compte"><a href="../Php/CreateAnAccount.php">Créer un compte</a></li>';

            }
            ?>
        </ul>
    </div>

    <script>
        const nav2 = document.querySelector('div');
        const nav2Links = nav2.querySelector('ul');
        const seConnecter = document.getElementById('se-connecter');
        const creerCompte = document.getElementById('creer-compte');
        const seDeconnecter = document.getElementById('se-deconnecter');
        const profil = document.getElementById('profil');

        // Ajouter un écouteur d'événement pour le clic sur l'image
        document.getElementById('mon-image').addEventListener('click', () => {
            // Afficher ou masquer les éléments de la liste
            nav2Links.classList.toggle('active');
            if(seConnecter!=null){
                seConnecter.classList.toggle('hidden');
            }
            if (creerCompte!=null){
                creerCompte.classList.toggle('hidden');
            }
            if (seDeconnecter!=null){
                seDeconnecter.classList.toggle('hidden');
            }
            else{
                seDeconnecter.classList.toggle('visible');
            }
            if (profil!=null){
                profil.classList.toggle('hidden');
            }
        });
    </script>

</header>


    <!-- Bouton de menu -->
    <div class="menu-btn" onclick="toggleMenu()">


        <span class="text">Menu</span>
    </div>

    <!-- Menu horizontal -->
    <div class="menus">
        <!-- Options de menu -->
        <ul class="menus-options">
            <li class="menus-option"><a href="../Php/annonce.php">Proposer un trajet</a></li>
            <li class="menus-option"><a href="../Php/historique.php">Accéder à l'historique</a></li>
            <li class="menus-option"><a href="#">Chat</a></li>
            <li class="menus-option"><a href="Calendar.php">Calendrier</a></li>
            <li class="menus-option"><a href="../Php/Contact.php">Nous contacter</a></li>
        </ul>
    </div>
        <!-- Titre de la page Contact.php accompagné d'un petit message -->
    <h1>Contactez nous !</h1>
    <p>Nous mettons à votre disposition un moyen de nous contacter afin de vous fournir une assistance continue</p>

    <br>
    <br>

    <!-- div contenant les champs essentiels pour envoyer le message à l'équipe Coride Upssi -->
    <div class="contact">
        <form class="" action="Send.php" method="post">
            <label for="email">Adresse e-mail </label>
            <input type="email" id="email" name="email" placeholder="Veuillez entrer votre adresse mail" required><br><br>

            <label for="subject">Objet </label>
            <input type="text" id="subject" name="subject" placeholder="Veuillez définir l'objet de votre contact" required><br><br>

            <label for="message">Message </label>
            <textarea id="message" name="message" placeholder="En quoi pourrions-nous vous aider ?" required></textarea><br><br>

            <button type="submit" name="send">Envoyer</button>
        </form>
    </div>



    <!-- Script pour afficher / masquer les options de menu -->
    <script>
        function toggleMenu() {
            var menuOptions = document.querySelector(".menus-options");
            var menu = document.querySelector(".menus");
            if (menuOptions.style.display === "block") {
                menuOptions.style.display = "none";
                menu.style.width = "200px";
            } else {
                menuOptions.style.display = "block";
                menu.style.width = "400px";
            }
        }
    </script>
    <div class="blue-triangle"></div>





</body>

</html>