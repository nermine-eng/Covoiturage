<?php
//Connexion à la base de donnée 
$dbconn = pg_connect("host=localhost port=5432 dbname=web user=postgres password=Stri");
//ouverture de la session
session_start();
//verification si l'utilisateur est bien connecté 
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  $email = $_SESSION['email'];
  }
  //Récupérer l'id de l'utilisateur en connaissant le mail de l'utilisateur
  $queryGetId = "SELECT idutilisateur FROM utilisateur WHERE email = '$email' ";
  //Récupération de l'id de la requete
  $resultGetId = pg_query($dbconn, $queryGetId);
  //Boucler sur le resultat de la requete et initialiser la valeur de l'id utilisateur
  while ($row = pg_fetch_row($resultGetId)) {
    $idutilisateurResult[] = $row[0];
  }

//Requeter la base de donnée pour recuperer la note, lieu de depart et lieu arrivee pour l'utilisateur connecté 
$sql = "SELECT note, trajet.lieudepart, trajet.lieuarrivee from donneravis
INNER JOIN trajet 
    ON trajet.idtrajet = donneravis.idtrajet
Where idutilisateur = '$idutilisateurResult[0]'";
  //Récupération de l'id de la requete
$result = pg_query($dbconn, $sql);
//Requeter la base de donnée pour recuperer l'id du donneur d'avis pour l'utilisateur connecté
$queryGetIDDonneurAvis = "SELECT idutilisateurdonneuravis FROM donneravis WHERE idutilisateur = '$idutilisateurResult[0]' ";
  $resultGetIDDonneurAvis = pg_query($dbconn, $queryGetIDDonneurAvis);
//Boucler sur le resultat de la requete et initialiser la valeur de l'id donneur avis
  while ($row2 = pg_fetch_assoc($resultGetIDDonneurAvis)) {
    $iddonneuravis = htmlspecialchars($row2['idutilisateurdonneuravis']);
  }
//Requeter la base de donnée pour recuperer le nom prenom du donneur d'avis pour l'utilisateur connecté
$queryGetNomPrenomDonneurAvis = "SELECT nom,prenom FROM utilisateur WHERE idutilisateur = '$iddonneuravis' ";
  $resultGetNomPrenomDonneurAvis = pg_query($dbconn, $queryGetNomPrenomDonneurAvis);
//Boucler sur le resultat de la requete et initialiser la valeur de du prenom nom du donneur avis
  while ($row1 = pg_fetch_assoc($resultGetNomPrenomDonneurAvis)) {
    $prenomDonneurAvis = htmlspecialchars($row1['prenom']);
    $nomDonneurAvis = htmlspecialchars($row1['nom']);
  }
  


// Fermer la base de donnée 
pg_close($dbconn);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>View Reviews</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="viewreviews.css">

        <link rel="icon" type="image/png" href="tiret.png" class="tiret"> <!-- Définition du favicon en format PNG -->
        <script src="app.js"></script>
    </head>
<body class="light">
    <header>
        <img src="logo.png" alt="Logo de la page">
    
        <ul class="menu">
          <li>
            <a href="accueil.html" class="actif">Accueil</a>
          </li>
          <li>
            <a href="#">À propos</a>
          </li>
          <li>
            <a href="#">Aide</a>
          </li>
        </ul>
        <div>
          <img src="image.png" alt="se connecter" class="b" id="mon-image">
          <ul>
            <li id="se-connecter"><a href="#">Se connecter</a></li>
            <li id="creer-compte"><a href="#">Créer un compte</a></li>
            <li id="se-deconnecter"><a href="#">Se déconnecter</a></li>
          </ul>
        </div>
    
        <script>
          const nav2 = document.querySelector('div');
          const nav2Links = nav2.querySelector('ul');
          const seConnecter = document.getElementById('se-connecter');
          const creerCompte = document.getElementById('creer-compte');
          const seDeconnecter = document.getElementById('se-deconnecter');
    
          // Ajouter un écouteur d'événement pour le clic sur l'image
          document.getElementById('mon-image').addEventListener('click', () => {
            // Afficher ou masquer les éléments de la liste
            nav2Links.classList.toggle('active');
            seConnecter.classList.toggle('hidden');
            creerCompte.classList.toggle('hidden');
            seDeconnecter.classList.toggle('hidden');
          });
        </script>
    
      </header>
    
    
      <!-- Bouton de menu -->
      <div class="menu-btn" onclick="toggleMenu()">
    
    
        <span class="text">Menu</span>
      </div>
    
      <!-- Menu horizontal -->
      <div class="menus">
        <!-- Options de menu -->
        <ul class="menus-options">
          <li class="menus-option"><a href="#">Proposer un trajet</a></li>
          <li class="menus-option"><a href="#">Accéder à l'historique</a></li>
          <li class="menus-option"><a href="#">Chat</a></li>
          <li class="menus-option"><a href="#">Calendrier</a></li>
          <li class="menus-option"><a href="#">Nous contacter</a></li>
        </ul>
      </div>
    
      <!-- Script pour afficher / masquer les options de menu -->
      <script>
        function toggleMenu() {
          var menuOptions = document.querySelector(".menus-options");
          var menu = document.querySelector(".menus");
          if (menuOptions.style.display === "block") {
            menuOptions.style.display = "none";
            menu.style.width = "200px";
          } else {
            menuOptions.style.display = "block";
            menu.style.width = "400px";
          }
        }
      </script>
      <h1 style="margin-left:39%; margin-top:-5%; margin-bottom:-1%;"><b>Découvrez ce que les autres</b></h1>
      <h1 style="margin-left:39%; margin-bottom:5%;"><b>utilisateurs pensent de vous !</b></h1>
 
 
 <!-- creation d'un tableau qui affiche la note de l'utilisateur ainsi que Lieu de départ,Lieu de destination et le donneur d'avis -->
 <table style="margin-left: 25%">
  <tr>
    <th>Note</th>
    <th>Lieu de départ</th>
    <th>Lieu de destination</th>
    <th>Donneur d'avis</th>
  </tr>
  <?php
  //Boucler sur le résultat de la requete au début de la page et récupération de la note, lieu départ et lieu arrivé
  while ($row = pg_fetch_assoc($result)) {
    // Escape any special characters in the row data to prevent HTML injection
    $note = htmlspecialchars($row['note']);
    $from = htmlspecialchars($row['lieudepart']);
    $to = htmlspecialchars($row['lieuarrivee']);

    // Ajoutez une classe à la ligne du tableau si la note est de 4 ou plus pour lui donner un style différent
    $row_class = ($note >= 4) ? "positive-review" : "";
    
    // Créez le code HTML des étoiles en fonction de la valeur de la note
    $stars_html = "";
    for ($i = 1; $i <= $note; $i++) {
      $stars_html .= "<span class=\"star\">&#9733;</span>";
    }
    
    // Afficher la ligne dans le tableau
    echo "<tr class=\"$row_class\">";
    echo "<td class=\"star-rating\">$stars_html</td>";
    echo "<td>$from</td>";
    echo "<td>$to</td>";
    echo "<td>$prenomDonneurAvis $nomDonneurAvis</td>";
    echo "</tr>";
  }
  ?>
 </table>

  <!-- ajouter le paragraphe ci-dessous après le tableau -->
 <p style="margin-top: 60px; margin-left: 30%;"><b>Vous y êtes presque pour gagner une récompense ! </b></p>
 <div style="border: 1px solid black; width: 300px; margin-top: 15px; margin-left: 30%;">
  <div style="background-color: green; height: 20px; width: 60px;"></div>
</div>
<img src="coupe.png" style="width: 50px;margin-left: 53%;margin-top: -3%;">

</body>

</html>
