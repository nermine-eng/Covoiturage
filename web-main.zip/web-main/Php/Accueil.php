<?php

include 'Gabarit.php';

$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$user_query=pg_query($db, "SELECT * FROM utilisateur");

?>

<!DOCTYPE html>
  <title>Titre de la page</title>
  <link rel="stylesheet" href="../Css/Accueil.css">




  <div class="searchbardiv">
    <form class="searchbar" action="Search_function.php" method="get">
      <label for="villedepart">Ville de départ</label>
      <input type="text" id="villedepart" name="villedepart" placeholder="Entrez votre recherche...">
      <label for="villearrivee">Ville d'arrivée</label>
      <input type="search" id="villearrivee" name="villearrivee" placeholder="Entrez votre recherche...">
      <label for="datedepart">Date</label>
      <input type="date" id="datedepart" name="datedepart" placeholder="Entrez votre recherche...">
      <input type="submit" value="Recherche" name="recherche" onclick="search()">
    </form>
  </div>


</body>

</html>

