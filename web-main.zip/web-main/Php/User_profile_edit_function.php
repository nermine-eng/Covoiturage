<?php
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

$email = $_SESSION['email'];
$query = "SELECT * FROM UTILISATEUR";
$result = pg_query($db, $query);


$host = 'localhost';
$dbname = 'web';
$user = 'postgres';
$password = 'postgres';

// Chaîne de connexion à la base de données
$dsn = "pgsql:host=$host;dbname=$dbname;user=$user;password=$password";


// Création d'une instance PDO pour la connexion à la base de données
try {
    $pdo = new PDO($dsn);
    //echo 'Connexion réussie à la base de données PostgreSQL';
} catch (PDOException $e) {
    echo 'Connexion échouée : ' . $e->getMessage();
}

function opensubmit(){
    if (isset($_POST['enregistrer'])){
        header('Location : Submit_user_profil_changes.php');
    }
}
if ($result) {
// Parcours des résultats de la requête
    while ($row = pg_fetch_assoc($result)) {
        if ($row['email']==$email){
            // Récupération des données de l'utilisateur
            $nom = $row['nom'];
            $prenom = $row['prenom'];
            $age = $row['age'];
            $motDePasse = $row['motdepasse'];
            if ($row['image']!=NULL){
                $image = $row['image'];
            }
            else{
                $image = 'image.png';
            }
             // Formulaire de mise à jour du profil
            echo '<form action="Submit_user_profil_changes.php" method="post" enctype="multipart/form-data">';

            echo'<div class="form-group">';
            echo '<label for="photo">Photo :</label>';
            echo '<div class="custom-file" style="position: relative; overflow: hidden; display: inline-block;">';
            echo   ' <input type="file" class="custom-file-input" id="nouvphoto" name="nouvphoto" style="position: absolute; top: 0; right: 0; opacity: 0; font-size: 100px;">';
            echo  ' <label class="custom-file-label" for="nouvphoto" style="background-color: #000; color: #fff; border: none; padding: 5px 10px; outline: none; white-space: nowrap; -webkit-user-select: none; cursor: pointer; text-shadow: 1px 1px #000;">Choisir un fichier</label>';

            echo'</div>';
            echo '<br>';

            echo "<img id='image-profil' src='../external_files/$image' style='max-width: 100%; height: auto; width: 300px; border: 5px solid #000; object-fit: cover; object-position: center center'>";


            echo '</div>';

            echo '<div class="form-group">';
            echo '<label for="nom">Nom :</label>';
            echo '<input type="text" id="nom" name="nom" value="' . $nom . '" required pattern="[A-Za-z]{2,50}" title="Le nom doit avoir une longueur minimale de 2caractères et constitué uniquement de lettres" >';
            echo '</div>';

            echo '<div class="form-group">';
            echo '<label for="prenom">Prénom :</label>';
            echo '<input type="text" id="prenom" name="prenom" value="' . $prenom . '" required pattern="[A-Za-z]{2,50}" title="Le prénom doit avoir une longueur minimale de 2caractères et constitué uniquement de lettres">';
            echo '</div>';

            echo '<div class="form-group">';
            echo '<label for="date_naissance">Date de naissance :</label>';
            echo '<input type="date" id="date_naissance" name="date_naissance" value="' . $age . '" required max="' . date('Y-m-d', strtotime('-17 years')) . '">';
            echo '</div>';

            echo '<div class="form-group">';
            echo '<label for="mot_de_passe">Mot de passe :</label>';
            echo '<div class="input-group">';

            echo '<input type="password" id="mot_de_passe" name="mot_de_passe" value="' . $motDePasse . '" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?=.*\w)(?!.*\s).{8,}" title="Votre mot de passe doit contenir au moins 8 caractères, dont au moins unelettre majuscule, une lettre minuscule, un chiffre et un caractère spécial">';
            echo '<div class="input-group-append">';
            echo '<span class="show-password" onclick="togglePassword()">&#x1f441;</span>';

            echo '</div>';
            echo '</div>';
            echo '</div>';
 // Fonction pour basculer le type du champ mot de passe entre texte et mot de passe
            echo '<script>';
            echo 'function togglePassword() {';
            echo 'var x = document.getElementById("mot_de_passe");';
            echo 'if (x.type === "password") {';
            echo 'x.type = "text";';
            echo '} else {';
            echo 'x.type = "password";';
            echo '}';
            echo '}';
            echo '</script>';
// Conteneur des boutons
            echo '<div class="button-container">';
            echo '<input type="submit" class="enregistrer" id="enregistrer" value="Enregistrer" "()>';
            echo '<button type="button" onclick="confirmerAnnulation()">Annuler</button>';
            echo '</div>';
// Fonction de confirmation pour l'annulation
            echo '<script>';
            echo 'function confirmerAnnulation() {';
            echo 'if (confirm("Êtes-vous sûr de vouloir annuler ?")) {';
            echo 'window.location.href = "profil.php";';
            echo '} else {';
            echo 'return false;';
            echo '}';
            echo '}';
            echo '</script>';
        }
        echo '</form>'; // fermeture de la balise de formulaire
    }

}



pg_close($db);
?> 




