<?php

include 'Gabarit.php';
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$user_query=pg_query($db, "SELECT * FROM utilisateur");


?>

<!DOCTYPE html>


    <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">

<div class="tableau">

<?php
$buttonID_supp = $_GET['buttonID_sup'];
$idtrajet_sup = $_SESSION['buttonID'];
$user_supp_query=pg_query($db, "SELECT * FROM reserver");
while ($row = pg_fetch_array($user_supp_query)) {
    if ($row['idutilisateur']==$buttonID_supp){
        $query = pg_query($db, "DELETE FROM RESERVER WHERE idUtilisateur = $buttonID_supp AND idTrajet = $idtrajet_sup");
        echo "Cette personne à bien été désinscrite ! ";
    }

}


?>

</div>

</body>

</html>