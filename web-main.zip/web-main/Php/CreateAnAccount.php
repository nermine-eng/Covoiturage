<?php
include 'Gabarit.php';
// Connexion à la base de données PostgreSQL
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
// Requête pour récupérer tous les utilisateurs
$user_query=pg_query($db, "SELECT * FROM utilisateur");

// Vérification si le formulaire a été soumis (méthode POST)
if (isset($_POST["nom"])){
// Récupération des valeurs soumises dans le formulaire
  $query_nom = $_POST['nom'];
  $query_prenom=$_POST['prenom'];
  $query_email = $_POST['email'];
  $query_age = $_POST['date'];
  $query_motDePasse = $_POST['password'];
  $query_telephone = $_POST['telephone'];




// Handle user icon upload
  $originalFileName = $_FILES['photo']['name'];
  $targetDirectory = '../external_files/';
  $uploadOk = 1;
  $imageFileType = strtolower(pathinfo($originalFileName, PATHINFO_EXTENSION));

// Generate a unique filename based on the user
  $targetFile = $targetDirectory . $query_email .'.jpg';
  $photo = $query_email . '.jpg';
// ... (Rest of the validation checks)

// Move the uploaded file to the target directory
  if ($uploadOk == 1) {
    if ($_FILES['photo']['tmp_name']!=NULL){
      if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
        // File has been successfully uploaded, and you can save the file path to the user's account in your database.
        echo "File uploaded successfully.";
        // Save the file path in your database or perform any other necessary actions.
      }
    }
    else {
        $photo = "image.png";
        //$ext = "";
        echo "Default file added";
      }
  }


  //$ext = pathinfo($filename, PATHINFO_EXTENSION);
      echo "<script>alert('Votre compte a été créé avec succès!')</script>";

    }
if (isset($_POST["nom"])) {
  $query = "INSERT INTO UTILISATEUR (admin_var, nom, prenom, email, age, motDepasse, telephone,image) VALUES (0,'$query_nom', '$query_prenom', '$query_email', '$query_age', '$query_motDePasse', '$query_telephone','$photo')";
  $result = pg_query($db, $query);
}
?>

<!DOCTYPE html>
  <title>Page d'enregistrement</title>
  <link rel="stylesheet" href="../Css/CreateAnAccount.css">
  <script>
    function togglePassword() {
      var x = document.getElementById("password");
      if (x.type === "text") {
        x.type = "password";
      } else {
        x.type = "text";
      }
    }
  </script>




  <form action="CreateAnAccount.php" method="post" enctype="multipart/form-data">
    <h1>Créez un compte en quelques clics !</h1>
    <h6>Vous en avez déjà un? <a href="#">Connectez-vous</a>
    </h6>
    <br>
    <label for="nom">Nom </label>
    <br>
    <input type="text" id="nom" name="nom" placeholder="Veuillez entrer votre nom" required pattern="[A-Za-z]{2,50}"
      title="Le nom doit avoir une longueur minimale de 2caractères et constitué uniquement de lettres">
    <br>
    <label for="prenom">Prénom </label>
    <br>
    <input type="text" id="prenom" name="prenom" placeholder="Veuillez entrer votre prénom" required
      pattern="[A-Za-z]{2,50}"
      title="Le prénom doit avoir une longueur minimale de 2caractères et constitué uniquement de lettres">
    <br>
    <label for="email">Adresse email </label>
    <br>
    <input type="email" id="email" name="email" placeholder="Veuillez entrer votre adresse mail" required>
    <br>
    <label for="password">Mot de passe </label>
    <br>
    <div class="password-container">
      <span class="password-indicator">Votre mot de passe doit contenir au moins 8 caractères, dont au moins une
        lettre
        majuscule, une lettre minuscule, un chiffre et un caractère spécial.</span>
      <input type="password" id="password" name="password" placeholder="Veuillez choisir un mot de passe robuste "
        required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?=.*\w)(?!.*\s).{8,}"> <!--Mot de passe : il doit
            avoir une longueur minimale de 8 caractères, au moins une lettre minuscule, une lettre majuscule, un chiffre
            et un caractère spécial.-->

      <span class="show-password" onclick="togglePassword()">&#x1f441;</span>

    </div>
    <br>
    <label for="date">Date de naissance </label>
    <br>
    <input type="date" id="date" name="date" placeholder="Veuillez sélectionner votre date de naissance" required
      max="<?php echo date('Y-m-d', strtotime('-17 years')); ?>">
    <br>
    
   <label for="telephone">Numéro de téléphone</label><br>
<div class="telephone">
  <input type="tel" id="telephone" name="telephone" pattern="^\+\d{1,3}\s\d{6,14}$" required placeholder="+XX XXXXXXXXX">
</div>

    <br>
    <label for="photo">Photo de profil</label>
        <input type="file" id="photo" name="photo">
        
    <br>  

    <input type="submit" value="S'enregistrer">
  </form>

</body>

</html>