<?php
include 'Gabarit.php';
session_start();

$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$user_query=pg_query($db, "SELECT * FROM utilisateur");


$email = $_SESSION['email'];
$logged = $_SESSION['loggedin'];
$idtrajet = $_SESSION['buttonID'];

$utilisateur = pg_query($db, "SELECT * FROM utilisateur");
?>

<!DOCTYPE html>

    <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">


<div class="tableau" >
    <?php while ($row = pg_fetch_array($utilisateur)) {
        $emailcheck = $row['email'];
        $idutilisateur = $row['idutilisateur'];

        if($logged==true){
            if ($emailcheck==$email){
                $check = pg_query($db, "SELECT * FROM reserver WHERE reserver.idtrajet=$idtrajet AND reserver.idutilisateur=$idutilisateur");
                //$check_annuler = pg_query($db, "SELECT * FROM annuler WHERE annuler.idtrajet=$idtrajet AND annuler.idutilisateur = $idutilisateur");
                if ($row2 = pg_fetch_row($check)>0){
                    echo "Déja enregistré !";
                }
                else{
                    $query = pg_query($db, "INSERT INTO RESERVER (idUtilisateur, idTrajet) VALUES ($idutilisateur, $idtrajet)");
                    $query = pg_query($db, "UPDATE trajet SET nbplaces=nbplaces-1 WHERE idtrajet=$idtrajet ");
                    //$query = pg_query($db, "DELETE FROM annuler WHERE idtrajet=$idtrajet AND idutilisateur=$idutilisateur");




                    echo "Vous avez été enregistré ! ";
                }

            }
        }
        else{
            echo "You must be logged in !";
        }
    }?>
</div>

</body>

</html>