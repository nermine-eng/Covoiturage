<?php
session_start();

// Connect to the PostgreSQL database
$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

// Retrieve the username and password entered by the user
$email = $_POST['email'];
$motdepasse = $_POST['motdepasse'];


$res = pg_get_result($db);
if ($res !== false) {
    pg_free_result($res);
}


$sql = "SELECT * FROM utilisateur WHERE email=$1 AND motdepasse=$2";




$res = pg_query_params($db, $sql, array($email, $motdepasse));

if (!$res) {
    echo "Query failed: " . pg_last_error();
    exit();
}
$result = pg_fetch_assoc($res);


if (!empty($result) == 1) {
    // Log the user in by setting session variables

    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $email;



    // Redirect the user to the home page or some other page
    header("Location: ../Php/Accueil.php");
    exit();
} else {
    // If the username and password do not match, show an error message
    echo "Incorrect username or password";
}

