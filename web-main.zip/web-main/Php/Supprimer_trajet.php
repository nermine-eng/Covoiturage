<?php

include 'Gabarit.php';
$db = OpenCon();
$user_query=pg_query($db, "SELECT * FROM utilisateur");


?>

<!DOCTYPE html>

    <title>Titre de la page</title>
    <link rel="stylesheet" href="../Css/ReserverAnnulerSupprimerDesinscrire_trajet.css">


<div class="tableau">

    <?php
    $idtrajet_sup = $_SESSION['buttonID'];
    $trajet_supp_query=pg_query($db, "SELECT * FROM trajet");
    $user_trajet_supp_query = pg_query($db, "SELECT * FROM reserver");
    $driver_trajet_supp_query = pg_query($db, "SELECT * FROM proposer");
    $avis_trajet_supp_query = pg_query($db, "SELECT * FROM donneravis");
    $partir_trajet_supp_query = pg_query($db, "SELECT * FROM partir");
    $arriver_trajet_supp_query = pg_query($db, "SELECT * FROM arriver");

    while ($row = pg_fetch_array($trajet_supp_query)) {
        if ($row['idtrajet']==$idtrajet_sup){
            while($row2=pg_fetch_array($user_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM RESERVER WHERE idtrajet = $idtrajet_sup");

            }
            while ($row3=pg_fetch_array($driver_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM proposer WHERE idtrajet = $idtrajet_sup");

            }


            while($row3=pg_fetch_array($avis_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM donneravis WHERE idtrajet = $idtrajet_sup");

            }

            while($row4=pg_fetch_array($partir_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM partir WHERE idtrajet = $idtrajet_sup");

            }

            while($row5=pg_fetch_array($arriver_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM arriver WHERE idtrajet = $idtrajet_sup");

            }

            while($row6=pg_fetch_array($avis_trajet_supp_query)){
                $query = pg_query($db, "DELETE FROM DONNERAVIS WHERE idtrajet = $idtrajet_sup");

            }
            $query = pg_query($db, "DELETE FROM trajet WHERE idtrajet = $idtrajet_sup");
        }



    }
    echo "Le Trajet a été supprimé !";
    ?>

</div>

</body>

</html>