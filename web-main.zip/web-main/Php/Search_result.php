<?php

session_start();

$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");
$villedepart = $_SESSION['villedepart'];
$villearrivee = $_SESSION['villearrivee'];
$jourdepart = $_SESSION['datedepart'];
$result = $_SESSION['result'];
$user_query=pg_query($db, "SELECT * FROM utilisateur");
$result = pg_query($db, "SELECT * FROM trajet
INNER JOIN proposer ON trajet.idtrajet = proposer.idtrajet
INNER join utilisateur on proposer.idutilisateur = utilisateur.idutilisateur");

?>

<!DOCTYPE html>

<link rel="stylesheet" href="../Css/Search_result.css">


<body>




<header>
    <img src="../external_files/logo.png" alt="Logo de la page">

    <ul class="menu">
        <li>
            <a href="Accueil.php" class="actif">Accueil</a>
        </li>
        <li>
            <a href="#">À propos</a>
        </li>
        <li>
            <a href="#">Aide</a>
        </li>
    </ul>
    <div>
        <?php

        $image = 'image.png';
        $check =0;
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            $email = $_SESSION['email'];
            while ($row = pg_fetch_array($user_query)) {
                $emailcheck = $row['email'];

                if ($email == $emailcheck) {
                    $usersurname = $row['nom'];
                    $username = $row['prenom'];
                    $image = $row['image'];
                    $check = 1;
                } else {
                    $image = 'image.png';
                    $check = 0;
                }
            }
        }
        echo "<img  src='../external_files/$image' alt='se connecter' class='b' id='mon-image'>" ?>

        <ul>
            <?php


            if($check==1){
                echo $username, $usersurname;
                echo '<li id="profil"><a href="../Php/Profil.php">Profil</a></li>';
                echo '<li id="se-deconnecter"><a href="Disconnect_function.php">Se déconnecter</a></li>';
            }

            else {
                // Si l'utilisateur n'est pas connecté, afficher le lien "Se connecter"
                echo '<li id="se-connecter"><a href="../Php/Login.php">Se connecter</a></li>';
                echo '<li id="creer-compte"><a href="../Php/CreateAnAccount.php">Créer un compte</a></li>';

            }
            ?>
        </ul>
    </div>

    <script>
        const nav2 = document.querySelector('div');
        const nav2Links = nav2.querySelector('ul');
        const seConnecter = document.getElementById('se-connecter');
        const creerCompte = document.getElementById('creer-compte');
        const seDeconnecter = document.getElementById('se-deconnecter');
        const profil = document.getElementById('profil');

        // Ajouter un écouteur d'événement pour le clic sur l'image
        document.getElementById('mon-image').addEventListener('click', () => {
            // Afficher ou masquer les éléments de la liste
            nav2Links.classList.toggle('active');
            if(seConnecter!=null){
                seConnecter.classList.toggle('hidden');
            }
            if (creerCompte!=null){
                creerCompte.classList.toggle('hidden');
            }
            if (seDeconnecter!=null){
                seDeconnecter.classList.toggle('hidden');
            }
            else{
                seDeconnecter.classList.toggle('visible');
            }
            if (profil!=null){
                profil.classList.toggle('hidden');
            }
        });
    </script>

</header>


<!-- Bouton de menu -->
<div class="menu-btn" onclick="toggleMenu()">


    <span class="text">Menu</span>
</div>

<!-- Menu horizontal -->
<div class="menus">
    <!-- Options de menu -->
    <ul class="menus-options">
        <li class="menus-option"><a href="#">Proposer un trajet</a></li>
        <li class="menus-option"><a href="../Php/historique.php">Accéder à l'historique</a></li>
        <li class="menus-option"><a href="#">Chat</a></li>
        <li class="menus-option"><a href="Calendar.php">Calendrier</a></li>
        <li class="menus-option"><a href="../Php/Contact.php">Nous contacter</a></li>
    </ul>
</div>

<!-- Script pour afficher / masquer les options de menu -->
<script>
    function toggleMenu() {
        var menuOptions = document.querySelector(".menus-options");
        var menu = document.querySelector(".menus");
        if (menuOptions.style.display === "block") {
            menuOptions.style.display = "none";
            menu.style.width = "200px";
        } else {
            menuOptions.style.display = "block";
            menu.style.width = "400px";
        }
    }
    function sendID(buttonID) {
        window.location.href = "Details.php?buttonID=" + buttonID;
    }
</script>
<div class="blue-triangle"></div>

<h1 class="resulttext" style ="text-align: center">
    Les résultats de votre recherche en date du :
    <?php
    echo $jourdepart;
    ?>
</h1>
<html>
<div class="phpcontainer", style="text-align: center">

    <?php

    $i = 0;
    while ($row = pg_fetch_array($result)) {
        $lieudepart = $row['lieudepart'];
        $lieuarrivee = $row['lieuarrivee'];
        $heuredepart = $row['heuredepart'];
        $heurearrivee = $row['heurearrivee'];
        $datedepart = $row['datedepart'];
        $idtrajet = $row['idtrajet'];
        $idutilisateur = $row['idutilisateur'];
        $prenom = $row['prenom'];
        $nom = $row['nom'];
        $nbplaces = $row['nbplaces'];
        if ($nbplaces>0){
            $status = 'il reste '.$nbplaces.' places';
        }
        else{
            $status = 'Complet';
        }

        if($lieudepart==$villedepart AND $lieuarrivee==$villearrivee AND $datedepart==$jourdepart){

            echo "<div  style = 'background-color: #dddddd;  border-radius: 10px;'>
                    <div style='display: inline-flex' >
                        <ul>
                            <p>
                                Conducteur : $prenom $nom
                                
                            </p>
                        </ul>
                        <ul>
                            <p>
                                Au départ de : $villedepart
                            </p>
                        </ul>
                        <ul>
                            <p>
                                à : $heuredepart
                            </p>
                        </ul>
                        <ul>
                            <p>
                                Arrive à : $villearrivee
                            </p>
                        </ul>
                        <ul>
                            <p>
                                à : $heurearrivee
                            </p>
                        </ul>
                        <ul>
                                <button id='$idtrajet' onclick='sendID(this.id)'>
                                    Détails
                                </button>
                                <p>
                                $status
                                </p>
                        </ul>
                    </div>
                </div>";
            echo "<div style='width: 40px; height: 40px;'></div>";
        }
    }

    ?>
</div>
</html>


</body>

</html>