<?php
include 'Gabarit.php';

$db = OpenCon();
$user_query=pg_query($db, "SELECT * FROM utilisateur");


?>

<!DOCTYPE html>

    <link rel="stylesheet" href="../Css/Login.css">





<form class="loginform" action="../Php/Login_function.php" method="POST">
    <h1>Connectez vous !</h1>

    <label>E-MAIL</label>
    <input type="email" id="email" name="email" placeholder="Adresse mail" required>

    <br><label1>MOT DE PASSE</label1>
    <input type="password" id="motdepasse" name="motdepasse" placeholder="Password" required>
    <div class="password-container">
        <span class="show-password" onclick="togglePassword()">&#x1f441;</span>
    </div>
    <p>
        <a href="Forgot_password.php">Mot de passe oublié ?</a>
    </p>
    <input type="submit" value="Se connecter">

</form>

</body>

</html>