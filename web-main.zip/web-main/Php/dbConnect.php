<?php


function OpenCon()
 { 
 $host = "localhost";
 $port = "5432";
 $dbname = "web";
 $user = "postgres";
 $password = "postgres";
 
   // Connect to the PostgreSQL database
   $db = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

   if (!$db) {
      echo "Error : Unable to open database\n";
   }

   return $db;

 }
 
function CloseCon($conn)
 {
    // Close the database connection
   pg_close($conn);
 }
 

?>
