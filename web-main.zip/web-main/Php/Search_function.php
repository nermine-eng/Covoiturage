<?php

session_start();

$db = pg_connect("host=localhost port=5432 dbname=web user=postgres password=postgres");

$villedepart=$_GET["villedepart"];
$villearrivee=$_GET["villearrivee"];
$datedepart=$_GET["datedepart"];
$recherche=$_GET["recherche"];

$result = pg_query($db, "SELECT * FROM trajet where lieudepart = '$villedepart' and lieuarrivee = '$villearrivee'");


// Vérification de la requête
if (!$result) {
    echo "Erreur d'exécution de la requête.";
    exit;
}

$row = pg_fetch_assoc($result);

$result_value = 0;

// Récupération des valeurs
if (pg_num_rows($result)>0) {
    $_SESSION['newsearch'] = true;
    $_SESSION['villedepart'] = $villedepart;
    $_SESSION['villearrivee'] = $villearrivee;
    $_SESSION['datedepart'] = $datedepart;
    $_SESSION['row'] = $row;
    $_SESSION['result'] = $result;
    header("Location:Search_result.php");
    exit;
}
else{
    header("Location:Search_result.php");
}



// Libération des résultats et fermeture de la connexion
pg_free_result($result);
pg_close($db);

//&& !empty(trim($villedepart)) && !empty(trim($villearrivee)) && !empty(trim($datedepart))//
?>





