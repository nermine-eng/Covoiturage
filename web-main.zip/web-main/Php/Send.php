<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Inclusion des classes de PHPMailer
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';


if(isset($_POST["send"])){
    $mail= new PHPMailer(true);
// Configuration des paramètres du serveur SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'corideupssi@gmail.com';
    $mail->Password ='loughkceqkgxbikl';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
 // Configuration des informations de l'e-mail
    $mail->setFrom($_POST["email"]); // Définition de l'adresse e-mail de l'expéditeur
    $mail->addReplyTo($_POST["email"]); // Définition de l'adresse e-mail de réponse

    $mail->addAddress('corideupssi@gmail.com'); // Ajout de l'adresse e-mail de destination

    $mail->isHTML(true); // Définition du format du contenu comme HTML
    $mail->Subject = $_POST["subject"]; // Définition du sujet de l'e-mail
    $mail->Body = $_POST["message"]; // Définition du corps de l'e-mail


}
// Envoi de l'e-mail et gestion des résultats
if($mail->send()){
    // Affichage d'une alerte de succès et redirection vers une page
    echo "<script> alert('Votre message a bien été envoyé vous receverez une réponse de la part de l'équipe Coride Upssi dans les plus brefs délais'); window.location='contact.php'; </script>";
} else {
    // Affichage d'une alerte d'erreur et redirection vers une page
    echo "<script> alert('Une erreur s'est produite lors de l'envoi de votre message, veuillez réessayer plus tard.'); window.location='contact.php'; </script>";
}


?>