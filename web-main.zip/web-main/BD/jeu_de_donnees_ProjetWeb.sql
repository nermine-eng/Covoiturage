INSERT INTO UTILISATEUR (email, admin_var,nom, prenom, age, motDePasse, telephone)
VALUES
       ('user1@gmail.com', 1, 'Dupont', 'Jean', '25/12/2023', 'password1!', '0123456789'),
       ('user2@gmail.com', 0, 'Martin', 'Lucie', '31/12/2002', 'password2#', '0678901234'),
       ('user3@gmail.com', 0, 'Lefevre', 'Julien', '02/07/2000', 'password3$', '0156789012'),
       ('user4@gmail.com', 0, 'Garcia', 'Marie', '28/03/1999', 'password4%', '0689123456'),
       ('user5@gmail.com', 0, 'Moreau', 'Pierre', '07/09/2003', 'password5^', '0145678901'),
       ('user6@gmail.com', 0, 'Leroy', 'Anne', '29/12/2000', 'password6&', '0690123456'),
       ('user7@gmail.com', 0, 'Fournier', 'Thierry', '05/11/2005', 'password7*', '0134567890'),
       ('user8@gmail.com', 0, 'Rousseau', 'Sophie', '26/07/2007', 'password8(', '0656789012'),
       ('user9@gmail.com', 0, 'Barbier', 'Emmanuel', '05/06/1985', 'password9)', '0145678901'),
       ('user10@gmail.com', 0, 'Perrin', 'Laure', '24/09/1995', 'password10_', '0623456789');


INSERT INTO VOITURE (immatricule, modele, marque, nbPlacesDispo, specification)
VALUES 
('AB-123-CD', '208', 'Peugeot', 4, 'Belle petite citadine'),
('EF-456-GH', 'Clio', 'Renault', 5, 'Voiture pratique pour les familles'),
('IJ-789-KL', 'Golf', 'Volkswagen', 5, 'Voiture allemande très fiable'),
('MN-012-OP', '308', 'Peugeot', 4, 'Confortable pour les longs trajets'),
('QR-345-ST', 'Megane', 'Renault', 5, 'Voiture économique et confortable'),
('UV-678-WX', '208', 'Peugeot', 4, 'Voiture compacte et maniable'),
('YZ-901-AB', 'C3', 'Citroen', 5, 'Voiture originale et confortable'),
('CD-234-EF', 'A3', 'Audi', 5, 'Voiture haut de gamme et confortable'),
('GH-567-IJ', 'Clio', 'Renault', 5, 'Voiture économique et pratique'),
('KL-890-MN', 'Golf', 'Volkswagen', 5, 'Voiture allemande spacieuse et fiable');

INSERT INTO TRAJET (lieuDepart, lieuArrivee, dateDepart, dateArrivee, HeureDepart, HeureArrivee, nbPlaces)
VALUES 
('Paris', 'Lyon', '2023-04-20', '2023-04-20', '09:00:00', '12:00:00', 3),
('Paris', 'Lyon', '2023-04-20', '2023-04-20', '10:00:00', '13:00:00', 3),
('Marseille', 'Toulouse', '2023-04-22', '2023-04-22', '14:00:00', '17:00:00', 4),
('Lille', 'Bordeaux', '2023-04-25', '2023-04-25', '11:00:00', '18:00:00', 2),
('Nice', 'Nantes', '2023-04-27', '2023-04-27', '07:00:00', '16:00:00', 5),
('Toulon', 'Montpellier', '2023-04-28', '2023-04-28', '12:00:00', '15:00:00', 3),
('Grenoble', 'Rouen', '2023-05-01', '2023-05-01', '10:00:00', '16:00:00', 2),
('Strasbourg', 'Angers', '2023-05-03', '2023-05-03', '13:00:00', '21:00:00', 4),
('Brest', 'Dijon', '2023-05-06', '2023-05-06', '08:00:00', '18:00:00', 3),
('Saint-Etienne', 'Limoges', '2023-05-08', '2023-05-08', '16:00:00', '19:00:00', 2),
('Nancy', 'Clermont-Ferrand', '2023-05-10', '2023-05-10', '10:00:00', '15:00:00', 5);

INSERT INTO VILLE (nomVille) VALUES
('Paris'),
('Marseille'),
('Lyon'),
('Toulouse'),
('Nice'),
('Nantes'),
('Strasbourg'),
('Montpellier'),
('Bordeaux'),
('Lille'),
('Rennes'),
('Mulhouse');

-- INSERT INTO ADMINISTRATEUR (emailAdmin, motDePasseAdmin) VALUES
-- ('admin1@gmail.com', 'password01'),
-- ('admin2@gmail.com', 'password02'),
-- ('admin3@gmail.com', 'password03'),
-- ('admin4@gmail.com', 'password04'),
-- ('admin5@gmail.com', 'password05'),
-- ('admin6@gmail.com', 'password06'),
-- ('admin7@gmail.com', 'password07'),
-- ('admin8@gmail.com', 'password08'),
-- ('admin9@gmail.com', 'password09'),
-- ('admin10@gmail.com', 'password10');

-- -- -- -- -- -- -- -- -- -- -- -- -- -- 

INSERT INTO POSSEDER (idUtilisateur, Immatricule) VALUES
(1, 'AB-123-CD'),
(2, 'EF-456-GH'),
(3, 'IJ-789-KL'),
(4, 'MN-012-OP'),
(5, 'QR-345-ST'),
(6, 'UV-678-WX'),
(7, 'YZ-901-AB'),
(8, 'CD-234-EF'),
(9, 'GH-567-IJ'),
(10, 'KL-890-MN');

INSERT INTO PROPOSER (idUtilisateur, idTrajet)
VALUES
(1, 3),
(2, 7),
(3, 1),
(4, 8),
(5, 2),
(6, 6),
(7, 9),
(8, 4),
(9, 5);

INSERT INTO RESERVER (idUtilisateur, idTrajet)
VALUES
(2, 1),
(3, 2),
(4, 2),
(5, 3),
(6, 3),
(7, 4),
(8, 4),
(9, 5),
(10, 5);

-- INSERT INTO ANNULER (idUtilisateur, idTrajet)
-- VALUES
-- (1, 1),
-- (2, 3),
-- (3, 2),
-- (4, 1),
-- (5, 4),
-- (6, 3),
-- (7, 2),
-- (8, 4),
-- (9, 1),
-- (10, 3);

INSERT INTO DONNERAVIS (idUtilisateur, idTrajet, note)
VALUES 
(1, 10, 4),
(2, 1, 3),
(3, 9, 5),
(4, 8, 2),
(5, 5, 4),
(6, 2, 1),
(7, 3, 3),
(8, 4, 4),
(9, 6, 2),
(10, 7, 5);

--INSERT INTO OBTENIR (idUtilisateur, idRecompense)
--VALUES
    --(1, 1),
    --(1, 2),
    --(2, 3),
    --(2, 4),
    --(3, 5),
    --(4, 6),
    --(5, 7),
    --(6, 8),
    --(7, 9),
    --(8, 10);

-- INSERT INTO SARRETER (idTrajet, nomVille)
-- VALUES (1, 'Paris'),
--        (1, 'Lyon'),
--        (2, 'Bordeaux'),
--        (2, 'Toulouse'),
--        (3, 'Marseille'),
--        (3, 'Nice'),
--        (4, 'Nantes'),
--        (4, 'Rennes'),
--        (5, 'Strasbourg'),
--        (5, 'Mulhouse');

INSERT INTO PARTIR (idTrajet, nomVille)
VALUES (1, 'Paris'),
       (2, 'Marseille'),
       (3, 'Lyon'),
       (4, 'Toulouse'),
       (5, 'Nice'),
       (6, 'Nantes'),
       (7, 'Strasbourg'),
       (8, 'Montpellier'),
       (9, 'Bordeaux'),
       (10, 'Lille');

INSERT INTO ARRIVER (idTrajet, nomVille)
VALUES (1, 'Paris'), 
       (2, 'Lyon'), 
       (3, 'Marseille'),
       (4, 'Bordeaux'),
       (5, 'Toulouse'),
       (6, 'Nice'),
       (7, 'Nantes'),
       (8, 'Rennes'),
       (9, 'Strasbourg'),
       (10, 'Lille');

UPDATE RESERVER
SET idTrajet = 8
WHERE idUtilisateur = 2;

UPDATE RESERVER
SET idTrajet = 9
WHERE idUtilisateur = 4;

UPDATE RESERVER
SET idTrajet = 7
WHERE idUtilisateur = 6;

UPDATE RESERVER
SET idTrajet = 10
WHERE idUtilisateur = 7;


UPDATE donneravis
SET idutilisateurdonneuravis = 1
WHERE idUtilisateur = 2;

UPDATE donneravis
SET idutilisateurdonneuravis = 3
WHERE idUtilisateur = 6;

UPDATE donneravis
SET idutilisateurdonneuravis = 5
WHERE idUtilisateur = 7;

UPDATE donneravis
SET idutilisateurdonneuravis = 9
WHERE idUtilisateur = 5;

UPDATE donneravis
SET idutilisateurdonneuravis = 2
WHERE idUtilisateur = 4;

UPDATE donneravis
SET idutilisateurdonneuravis = 4
WHERE idUtilisateur = 3;

UPDATE donneravis
SET idutilisateurdonneuravis = 6
WHERE idUtilisateur = 10;

UPDATE donneravis
SET idutilisateurdonneuravis = 7
WHERE idUtilisateur = 1;